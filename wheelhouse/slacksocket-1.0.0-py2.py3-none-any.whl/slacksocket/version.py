__version__ = (1, 0, 0)
version = '%d.%d.%d' % __version__
